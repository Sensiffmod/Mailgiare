# Mailora V15 — Hiệu ứng GIF thật trong sản phẩm

Đã khắc phục lỗi ở V14: hiệu ứng GIF bị CSS lớp trắng che và bị sai thứ tự ưu tiên.

- Mỗi card tạo một lớp `.product-motion-layer` có GIF chuyển động màu trắng–tím do bạn cung cấp. CSS nằm cuối `head`, ưu tiên cao để không bị ghi đè.
- Giữ trọn hai bên sóng tím của GIF trong khung card dọc, chữ và giá vẫn nằm trên hiệu ứng.
- Đăng nhập / đăng ký hiển thị logo ảnh Mailora.

`index.html` là bản tự chạy trên Chrome (đã nhúng ảnh và GIF); hai tệp ảnh trong ZIP được đính kèm riêng để bạn có thể thay đổi sau.

Ghi chú kỹ thuật: đây vẫn là phiên bản giao diện chạy cục bộ; muốn dùng tài khoản và đối soát ngân hàng thật, cần hệ thống máy chủ an toàn.
